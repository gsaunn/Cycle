package com.example.virock.myapplication;

/**
 * Created by Virock on 18-Jun-15.
 */
public class bootCompletedBroadcastReceiver {
}
